package org.milfist.decorator;

public interface Car {
	public void assemble();
}

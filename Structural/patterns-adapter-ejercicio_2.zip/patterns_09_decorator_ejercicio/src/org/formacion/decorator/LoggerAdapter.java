package org.formacion.decorator;

import java.util.List;

public class LoggerAdapter implements BaseDatos {

	@Override
	public void inserta(String registro) {
		// implementar
	}

	@Override
	public List<String> registros() {
		// implementar
		return null;
	}

	

}

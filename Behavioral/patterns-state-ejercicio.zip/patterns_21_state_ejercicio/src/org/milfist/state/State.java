package org.milfist.state;

public interface State {
	public void doAction(Context context);
}

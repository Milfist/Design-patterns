package org.milfist.memento;

public interface Memento {

	public String getState();

}

package org.milfist.iterator;

public interface Container {
	public Iterator getIterator();
}

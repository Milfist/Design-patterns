package org.milfist.observer.inheritance;

public interface Observer {
	public abstract void update();
}
